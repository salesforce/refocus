/*
 * Remember our rules for modifying the DOM -- only under #lens!
 */
const lens = document.getElementById('lens');

/*
 * Register an event listener to handle the refocus.lens.load event.
 */
lens.addEventListener(lensUtils.evt.load, () => {
  // Add a heading to the lens.
  const h = document.createElement('h1');
  h.appendChild(document.createTextNode('My Hierarchy'));
  lens.appendChild(h);

  // Add a "loading" indicator to the lens.
  const loading = document.createElement('p');
  loading.setAttribute('id', 'loading');
  loading.appendChild(document.createTextNode('Loading...'));
  lens.appendChild(loading);
});

/**
 * Update the DOM to display the subject's absolutePath.
 *
 * @param {Object} subject - The subject to display.
 */
function renderSubject(subject) {
  // Generate a heading and append it to the lens.
  const h2 = document.createElement('h2');
  h2.appendChild(document.createTextNode(subject.absolutePath));
  lens.appendChild(h2);
} // renderSubject

/*
 * Register an event listener to handle the refocus.lens.hierarchyLoad event.
 */
lens.addEventListener(lensUtils.evt.hLoad, (evt) => {
  // Traverse the subjects and call renderSubject for each one.
  lensUtils.traverseSubjects(evt.detail, renderSubject);

  // Hide the "loading" indicator.
  document.getElementById('loading').style.display = 'none';
});

_ldk.selectSampleData();
